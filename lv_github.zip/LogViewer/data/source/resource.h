#define ID_PIC 1000
//ALL the resource IDs inside this file
